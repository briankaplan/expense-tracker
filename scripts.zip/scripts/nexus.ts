const chalk = require('chalk');
const { execSync } = require('child_process');
const { program } = require('commander');
const { DevelopmentDashboard } = require('./dashboard');
const { stateSync } = require('./sync-manager');
const { recoveryManager } = require('./recovery-manager');
const { sessionManager } = require('./session-state');
const { MilestoneTracker } = require('./milestone-tracker');
const { MilestoneNotifier } = require('./notifications/milestone-notifications');
const { MilestoneAutomation } = require('./automation/milestone-automation');
const { AIAssistant } = require('./ai/assistant');
const { ScriptVerifier } = require('./verify-scripts');
const { ImpactAnalyzer } = require('./analyze-impact');
const { DependencyChecker } = require('./dependency-checker');
const { CriticalPathMonitor } = require('./critical-path-monitor');
const { NexusBrain } = require('./nexus-brain');
const { GitHooksManager } = require('./hooks/git-hooks');
const { projectState } = require('./state/project-state');
const fs = require('fs');
const path = require('path');

interface NexusCommand {
  name: string;
  description: string;
  alias?: string;
  action: (...args: any[]) => Promise<void>;
}

interface NexusConfig {
  commands: NexusCommand[];
  hooks: string[];
  automations: string[];
}

function setupCommands() {
  program
    .name('nexus')
    .description('Nexus Development Control Center')
    .version('1.0.0');

  // Development Commands
  program
    .command('brain')
    .alias('b')
    .description('Run Nexus brain checks')
    .action(async () => {
      const brain = new NexusBrain();
      await brain.checkAndRun();
    });

  program
    .command('dashboard')
    .alias('d')
    .description('Open development dashboard')
    .action(async () => {
      const dashboard = new DevelopmentDashboard();
      await dashboard.start();
    });

  program
    .command('status')
    .alias('s')
    .description('Show current development status')
    .action(async () => {
      const state = projectState.getState();
      console.log(chalk.blue('\n📊 Development Status\n'));
      console.log(`Phase: ${chalk.yellow(state.currentPhase)}`);
      console.log(`Features: ${Object.keys(state.projectDefinition.pages).length}`);
      console.log(`Integrations: ${Object.keys(state.integrations).length}`);
    });

  // Verification Commands
  program
    .command('verify')
    .alias('v')
    .description('Run verification checks')
    .action(async () => {
      const verifier = new ScriptVerifier();
      await verifier.verifyAll();
    });

  program
    .command('impact')
    .alias('i')
    .description('Analyze impact of changes')
    .action(async () => {
      const analyzer = new ImpactAnalyzer();
      await analyzer.analyze();
    });

  // Feature Management
  program
    .command('feature')
    .alias('f')
    .description('Manage features')
    .option('-l, --list', 'List all features')
    .option('-a, --add <name>', 'Add new feature')
    .option('-u, --update <name>', 'Update feature status')
    .action(async (options) => {
      const tracker = new MilestoneTracker();
      if (options.list) await tracker.listFeatures();
      if (options.add) await tracker.addFeature(options.add);
      if (options.update) await tracker.updateFeature(options.update);
    });

  // Integration Management
  program
    .command('integration')
    .description('Manage integrations')
    .option('-l, --list', 'List integrations')
    .option('-c, --check', 'Check integration status')
    .action(async (options) => {
      if (options.list) {
        const state = projectState.getState();
        console.log(chalk.blue('\n🔌 Integrations\n'));
        Object.entries(state.integrations).forEach(([name, status]) => {
          console.log(`${name}: ${chalk.yellow(status.status)}`);
        });
      }
      if (options.check) {
        execSync('npm run verify:reference', { stdio: 'inherit' });
      }
    });

  // Reporting
  program
    .command('report')
    .alias('r')
    .description('Generate development reports')
    .action(async () => {
      console.log(chalk.blue('\n📋 Generating Report\n'));
      execSync('npm run verify:full', { stdio: 'inherit' });
    });

  // Tools and Utilities
  program
    .command('tools')
    .alias('t')
    .description('Development tools')
    .option('-c, --clean', 'Clean project')
    .option('-f, --fix', 'Fix common issues')
    .action(async (options) => {
      if (options.clean) execSync('npm run verify:cleanup', { stdio: 'inherit' });
      if (options.fix) execSync('npm run fix-imports', { stdio: 'inherit' });
    });

  // AI Assistant
  program
    .command('ai')
    .description('AI development assistant')
    .option('-h, --help', 'Show AI commands')
    .option('-r, --review', 'Review code')
    .option('-s, --suggest', 'Get suggestions')
    .action(async (options) => {
      const assistant = new AIAssistant();
      if (options.help) await assistant.showCommands();
      if (options.review) await assistant.reviewCode();
      if (options.suggest) await assistant.getSuggestions();
    });

  // Alerts and Notifications
  program
    .command('alerts')
    .description('Manage development alerts')
    .option('-l, --list', 'List active alerts')
    .option('-c, --clear', 'Clear alerts')
    .action(async (options) => {
      const notifier = new MilestoneNotifier();
      if (options.list) await notifier.listAlerts();
      if (options.clear) await notifier.clearAlerts();
    });

  // Automation
  program
    .command('auto')
    .description('Development automation')
    .option('-l, --list', 'List automations')
    .option('-r, --run <name>', 'Run automation')
    .action(async (options) => {
      const automation = new MilestoneAutomation();
      if (options.list) await automation.listAutomations();
      if (options.run) await automation.runAutomation(options.run);
    });
}

// Set up commands and parse arguments
setupCommands();
program.parse(process.argv);

module.exports = {
  setupCommands
}; 