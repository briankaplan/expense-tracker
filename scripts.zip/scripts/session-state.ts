const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

class SessionManager {
  // ... rest of the class implementation ...
}

const sessionManager = new SessionManager();

module.exports = {
  sessionManager
}; 